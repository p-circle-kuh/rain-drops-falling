# Hamiltonian Neural Networks | 2019
# Sam Greydanus, Misko Dzamba, Jason Yosinski

import autograd
import autograd.numpy as np

import scipy.integrate
solve_ivp = scipy.integrate.solve_ivp


def get_trajectory(noise_std=0.1, **kwargs):

  def my_func(t,x):
    p, q = x
    return [g * np.exp(-k*t), g * (1 - np.exp(-k*t)) / k]

  # Initial Values
  T_INITIAL = 0  # [s]
  p0 = 0.0
  q0 = 0.0
  init = [p0, q0]

  # Params for Phys.
  k = 1  # [1/s]
  g = 9.8  # [m/s]

  # Params for Calc.
  T_FINAL = 10  # [s]
  T_STEP = 0.1  # [s]

  n_steps = (T_FINAL - T_INITIAL) / T_STEP
  t_eval = T_INITIAL + np.arange(0, n_steps) * T_STEP
  t_span = [T_INITIAL, T_FINAL]

  result = solve_ivp(my_func, t_span, init, method='RK45', t_eval=t_eval)
  p = result.y[0,:] 
  q = result.y[1,:]
  dpdt = g * np.exp(-k*t_eval)
  dqdt = g * (1 - np.exp(-k*t_eval)) / k

  # add noise
  q += np.random.randn(*q.shape)*noise_std
  p += np.random.randn(*p.shape)*noise_std
  return q, p, dqdt, dpdt, t_eval


def get_dataset(seed=0, samples=50, test_split=0.5, **kwargs):
    data = {'meta': locals()}

    # randomly sample inputs
    np.random.seed(seed)
    xs, dxs = [], []
    for s in range(samples):
        x, y, dx, dy, t = get_trajectory(**kwargs)
        xs.append( np.stack( [x, y]).T )
        dxs.append( np.stack( [dx, dy]).T )
        
    data['x'] = np.concatenate(xs)
    data['dx'] = np.concatenate(dxs).squeeze()

    # make a train/test split
    split_ix = int(len(data['x']) * test_split)
    split_data = {}
    for k in ['x', 'dx']:
        split_data[k], split_data['test_' + k] = data[k][:split_ix], data[k][split_ix:]
    data = split_data
    return data

def get_field(xmin=-1.2, xmax=1.2, ymin=-1.2, ymax=1.2, gridsize=20):
    field = {'meta': locals()}

    # meshgrid to get vector field
    b, a = np.meshgrid(np.linspace(xmin, xmax, gridsize), np.linspace(ymin, ymax, gridsize))
    ys = np.stack([b.flatten(), a.flatten()])
    
    # get vector directions
    dydt = [dynamics_fn(None, y) for y in ys.T]
    dydt = np.stack(dydt).T

    field['x'] = ys.T
    field['dx'] = dydt.T
    return field